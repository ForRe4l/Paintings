package com.paintingscollectors.controller;

import com.paintingscollectors.config.UserSession;
import com.paintingscollectors.model.entity.Painting;
import com.paintingscollectors.model.entity.StyleName;
import com.paintingscollectors.repository.PaintingRepository;
import com.paintingscollectors.repository.UserRepository;
import com.paintingscollectors.service.AddPaintingService;
import com.paintingscollectors.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;
import java.util.Map;

@Controller
public class HomeController {

    private final UserSession userSession;
    private final PaintingRepository paintingRepository;
    private final AddPaintingService addPaintingService;
    private final UserService userService;
    private final UserRepository userRepository;

    public HomeController(UserSession userSession, PaintingRepository paintingRepository, AddPaintingService addPaintingService, UserService userService, UserRepository userRepository) {
        this.userSession = userSession;
        this.paintingRepository = paintingRepository;
        this.addPaintingService = addPaintingService;
        this.userService = userService;
        this.userRepository = userRepository;
    }

    @GetMapping("/")
    public String notLoggedUser() {
        if(userSession.userIsLogged()){
            return "redirect:/home";
        }

        return "index";
    }

    @GetMapping("/home")
    public String LoggedUser(Model model) {
        if(!userSession.userIsLogged()){
            return "redirect:/";
        }

        List<Painting> allUserPaintings = addPaintingService.findAllByOwner();
        if(!allUserPaintings.isEmpty()) {
            model.addAttribute("YourPaintings", allUserPaintings);
        }

        List<Painting> favoritePaintings = userService.getFavoritePaintings(userSession.getUsername());
        model.addAttribute("paintings", favoritePaintings);
        model.addAttribute("username", userSession.getUsername());


        return "home";
    }

}
