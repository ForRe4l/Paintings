package com.paintingscollectors.model.entity;

public enum StyleName {
    IMPRESSIONISM,
    ABSTRACT,
    EXPRESSIONISM,
    SURREALISM,
    REALISM,
}
