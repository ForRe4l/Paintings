package com.paintingscollectors.service;

import com.paintingscollectors.config.UserSession;
import com.paintingscollectors.model.dto.PaintingDTO;
import com.paintingscollectors.model.entity.Painting;
import com.paintingscollectors.model.entity.Style;
import com.paintingscollectors.model.entity.StyleName;
import com.paintingscollectors.model.entity.User;
import com.paintingscollectors.repository.PaintingRepository;
import com.paintingscollectors.repository.StyleRepository;
import com.paintingscollectors.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class AddPaintingService {
    private final PaintingRepository paintingRepository;

    private final UserSession userSession;
    private final UserRepository userRepository;
    private final StyleRepository styleRepository;

    public AddPaintingService(PaintingRepository paintingRepository, UserSession userSession, UserRepository userRepository, StyleRepository styleRepository) {
        this.paintingRepository = paintingRepository;
        this.userSession = userSession;
        this.userRepository = userRepository;
        this.styleRepository = styleRepository;
    }

    public boolean addPainting(PaintingDTO data) {

        Optional<User> byId = userRepository.findById(userSession.getId());

        if (byId.isEmpty()) {
            return false;
        }

        Optional<Style> byStyle = styleRepository.findByStyleName(data.getStyle());

        if (byStyle.isEmpty()) {
            return false;
        }

        Painting painting = new Painting();
        painting.setName(data.getName());
        painting.setAuthor(data.getAuthor());
        painting.setImageUrl(data.getImage());
        painting.setStyle(byStyle.get());
        painting.setOwner(byId.get());

        paintingRepository.save(painting);
        return true;
    }

    public List<Painting> findAllByOwner() {

        List<Painting> allUserPaintings = paintingRepository.findByOwner(userRepository.findById(userSession.getId()));

        return allUserPaintings;

    }

    public List<Painting> getAllPaintingsExceptUserFavorites(String username) {
        return paintingRepository.findAllExceptUserFavorites(username);
    }

}
