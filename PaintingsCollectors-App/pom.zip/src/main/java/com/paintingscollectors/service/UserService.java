package com.paintingscollectors.service;

import com.paintingscollectors.config.UserSession;
import com.paintingscollectors.model.dto.UserLoginDTO;
import com.paintingscollectors.model.dto.UserRegisterDTO;
import com.paintingscollectors.model.entity.Painting;
import com.paintingscollectors.model.entity.User;
import com.paintingscollectors.repository.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserSession loggedUser;
    private final ModelMapper modelMapper;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;


    public UserService(ModelMapper modelMapper,
                       UserRepository data,
                       PasswordEncoder passwordEncoder,
                       UserSession  loggedUser) {

        this.modelMapper = modelMapper;
        this.userRepository = data;
        this.passwordEncoder = passwordEncoder;
        this.loggedUser = loggedUser;
    }

        public boolean registerUser(UserRegisterDTO userData){

            if(!userData.getPassword().equals(userData.getConfirmPassword())) {
                return false;
            }

            boolean isUsernameOrEmailTaken =
                    userRepository.existsByUsernameOrEmail(userData.getEmail(), userData.getUsername());

            if (isUsernameOrEmailTaken) {
                return false;
            }

            User mappedUser = modelMapper.map(userData, User.class);
            mappedUser.setPassword(passwordEncoder.encode(userData.getPassword()));

            userRepository.save(mappedUser);
            return true;

        }

    public boolean loginUser(UserLoginDTO userData){
        Optional<User> byUsername = userRepository
                .findByUsername(userData.getUsername());

        if(byUsername.isEmpty()){
            return false;
        }
        User user = byUsername.get();
        if(!passwordEncoder.matches(userData.getPassword(), user.getPassword())){
            return false;
        }

        loggedUser.LoggedUser(user);
        return true;
    }

    public void logout(){
        loggedUser.logout();
    }


    public List<Painting> getFavoritePaintings(String username) {
        User user = userRepository.getByUsername(username);
        if (user != null) {
            return user.getFavoritePaintings();
        }
        return List.of();
    }

}
