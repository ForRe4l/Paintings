package com.paintingscollectors.config;

import com.paintingscollectors.model.entity.User;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

@Component
@SessionScope
public class UserSession {

    private long id;
    private String username;

    public void LoggedUser(User user) {
        this.id = user.getId();
        this.username = user.getUsername();
    }

    public boolean userIsLogged() {return id != 0;}

    public void logout(){
        id = 0;
        username = "";
    }

    public long getId() {
        return id;
    }
    public String getUsername() {
        return username;
    }


}
