package com.paintingscollectors.vallidation;

import com.paintingscollectors.repository.UserRepository;
import org.springframework.stereotype.Component;

@Component
public class UserValidation {

    private final UserRepository userRepository;

    public UserValidation(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public boolean fieldIsNotValid(String fieldData){
//        boolean userIsTaken = userRepository.getUserByUsername(username).getUsername().equals(username);
//        if(userIsTaken){
//            return "Username is already taken!";
//        }
        if(fieldData.length() < 3 || fieldData.length() > 20){return true;}
        return false;
    }

    public boolean emailIsEmpty(String email) {
        if(email.isEmpty()){return true;}
        return false;
    }

}
